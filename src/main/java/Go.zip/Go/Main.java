package Go;

public class Main {
    public static void main(){

    }
}
